RDC - 11 provinces (1988-2015) - shapefile
Source geometry: Natural Earth 1:10m Admin-1 (public domain), which still maps the DRC with its 11 pre-2015 provinces.
Coordinate system: WGS84 (EPSG:4326). Generalised boundaries at 1:10 million scale: good for maps, not for precise GIS overlay with health-zone limits.
Fields: PROVINCE, DPS_2003 (provincial health division at the time), CHEF_LIEU (capital), ISO_CODE (former ISO 3166-2 code),
PERIOD, DIST_2011 (health districts, PNDS 2011-2015), ZS_2011 (health zones, PNDS 2011-2015; total 515),
DPS_2015 (DPS created from the province in July 2015), SS_2005 (malaria sentinel site of the 11-site network).
Note: Sud-Kivu health districts = 5 (Mopene et al. 2020); the PNDS table shows 10 but its total of 65 only adds up with 5.
